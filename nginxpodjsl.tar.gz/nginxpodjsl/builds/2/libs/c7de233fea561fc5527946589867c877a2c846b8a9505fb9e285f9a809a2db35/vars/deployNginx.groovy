def call(Map config) { 
    // Define default values for Helm chart values 
    def defaults = [ 
        image: 'nginx:latest', 
        portType: 'NodePort' 
    ] 
  
    // Merge provided configuration with defaults 
    def helmValues = defaults + config 
  
    stage("Deploy Flink Application") { 
        def helmSetArgs = helmValues.collect { key, value -> "--set ${key}=${value}" }.join(' ') 
        sh "helm upgrade --install my-nginx-chart ./resources/ -f ./resources/values.yaml ${helmSetArgs}" 
    } 
} 
